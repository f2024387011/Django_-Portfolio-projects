from django.db import models
class Experience(models.Model):
    role = models.CharField(max_length=100) # Ismein "Web Developer" likhein
    company = models.CharField(max_length=100) # Ismein "Web Technology" likhein
    def __str__(self): return self.role