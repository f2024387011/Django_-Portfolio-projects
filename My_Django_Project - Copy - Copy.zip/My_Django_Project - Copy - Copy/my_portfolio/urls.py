from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from bio.views import home  # Ye line views ko connect karegi

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'), # Ye line aapka main home page banayegi
]

# Photos dikhane ke liye ye zaroori hai
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)