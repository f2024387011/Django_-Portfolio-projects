from django.shortcuts import render
from .models import Bio
from skills.models import Skill
from education.models import Education
from experience.models import Experience

def home(request):
    context = {
        'profile': Bio.objects.first(),
        'skills': Skill.objects.all(),
        'education': Education.objects.all(),
        'experience': Experience.objects.all(),
    }
    return render(request, 'index.html', context)p