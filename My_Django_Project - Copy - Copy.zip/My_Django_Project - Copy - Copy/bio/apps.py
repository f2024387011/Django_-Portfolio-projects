from django.apps import AppConfig


class BioConfig(AppConfig):
    name = 'bio'
