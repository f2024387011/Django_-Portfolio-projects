from django.db import models

# Create your models here.
from django.db import models

class Bio(models.Model):
    full_name = models.CharField(max_length=100)
    profile_picture = models.ImageField(upload_to='profile/')
    designation = models.CharField(max_length=100)
    about_me = models.TextField()

    def __str__(self):
        return self.full_name
